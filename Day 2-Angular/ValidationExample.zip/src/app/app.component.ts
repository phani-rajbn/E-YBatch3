import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  regForm : FormGroup;
  submitted : boolean = false;

  constructor(private builder : FormBuilder) {
    
  }

  ngOnInit(){
    this.regForm = this.builder.group({
      fname: ['', Validators.required],
      lname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      pwd: ['', [Validators.required, Validators.minLength(6)]],
    })
  }
  onSubmit() {
    this.submitted = true;
    if (this.regForm.invalid) {
      alert("Form is invalid")
      return;
    }
    alert("Success!!!");
  }
}
