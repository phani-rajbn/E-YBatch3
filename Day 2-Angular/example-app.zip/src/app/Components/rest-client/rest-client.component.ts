import { Component, OnInit } from '@angular/core';
import { BookService } from 'src/app/Services/book.service';

@Component({
  selector: 'app-rest-client',
  templateUrl: './rest-client.component.html',
  styleUrls: ['./rest-client.component.css']
})

export class RestClientComponent implements OnInit {
  allBooks : any = [];
  foundBook : any = null;
  constructor(private service: BookService) { }

  ngOnInit(): void {
    this.service.getAllBooks().subscribe((data)=>{
      this.allBooks = data;
    })
  }

  getRecord(id : string){
    this.service.findBook(id).subscribe((data)=>{
      this.foundBook = data;
    })
  }

  onSave(){
    this.service.updateBook(this.foundBook).subscribe((data)=>{
      alert("Data is updated");
    })
  }
}
