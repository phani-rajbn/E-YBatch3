import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { CalcComponent } from './Components/calc/calc.component';
import { BookManagerComponent } from './Components/book-manager/book-manager.component';
import { FilterPipe } from './Pipes/filter.pipe';
import { RestClientComponent } from './Components/rest-client/rest-client.component';
import { NewBookComponent } from './Components/new-book/new-book.component';
import { ValidationComponent } from './Components/validation/validation.component';

//Routes are url patterns that Ur app will recognize. 
const routes : Routes =[
  {
    path : '',
    redirectTo : 'calc',
    pathMatch : 'full'
  },
  {
    path: 'calc',
    component : CalcComponent
  },
  {
    path: "store",
    component: BookManagerComponent
  },
  {
    path: "Validation",
    component: ValidationComponent
  },
  {
    path : "newBook", 
    component : NewBookComponent
  },
  {
    path : "rest",
    component: RestClientComponent
  }
]

@NgModule({
  declarations: [
    AppComponent,
    CalcComponent,
    BookManagerComponent,
    FilterPipe,
    RestClientComponent,
    NewBookComponent,
    ValidationComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
