import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

//Form validations: Template Driven and Form Driven
@Component({
  selector: 'app-validation',
  templateUrl: './validation.component.html',
  styleUrls: ['./validation.component.css']
})
export class ValidationComponent implements OnInit {
  regForm : FormGroup;
  submitted : boolean = false;

  constructor(private builder : FormBuilder) { }

  ngOnInit(): void {
    this.regForm = this.builder.group([{
      fname :[ '', Validators.required],
      lname : [ '', Validators.required],
      email : ['', [Validators.required, Validators.email]],
      pwd : ['', [Validators.required, Validators.minLength(6)]]
    }]);
  }

  onSubmit(){
    this.submitted = true;
    if(this.regForm.invalid){
      return;
    }
    alert("Success!!!");
  }

}
