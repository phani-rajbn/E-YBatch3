import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Book } from '../Entities/book';

const baseUrl: string ="http://localhost:3000/employees";//location of ur server data...

//services are classes with directive called Injectable which means that these objects will have a sp feature of dependency injection. the components that depend on this service could get the reference of this service thro constructors in a simplified syntax. 
@Injectable({
  providedIn: 'root'
})
//This service is created to provide functions to operate on the Server like adding, deleting, updating and finding(CRUD operations). REST is a methodology of providing functionalities of CRUD operations thro HTTP verbs(GET(Reading), POST(Adding), PUT(Updating), DELETE). 
export class BookService {
  bookData : Array<Book> = null;

  constructor(private http: HttpClient) { 
    this.bookData = new Array<Book>();
  }

  getAllBooks() : Observable<any>{
     return this.http.get(baseUrl);//get method returns an observable object which is an async object that gives the data asynchronously .     
  }

  findBook(id: string) : Observable<any>{
     let bookid = parseInt(id);
     const tempUrl = baseUrl + "/" + bookid;
     return this.http.get(tempUrl);   
  }

  updateBook(book : any) : Observable<any>{
    const url = baseUrl + "/" + book.id;
    return this.http.put(url, book);
  }

  addNewBook(book: any) : Observable<any>{
    return this.http.post(baseUrl, book);
  }

  deleteBook(id : string) : Observable<any>{
    const bId = parseInt(id);
    const url = baseUrl + "/" + bId;
    return this.http.delete(url);
  }
}
