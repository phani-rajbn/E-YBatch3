import { Component, OnInit } from '@angular/core';
import { BookService } from 'src/app/Services/book.service';

@Component({
  selector: 'app-new-book',
  templateUrl: './new-book.component.html',
  styleUrls: ['./new-book.component.css']
})
export class NewBookComponent implements OnInit {
  id : number;
  title : string ;
  author : string;
  price : number;
  constructor(private service : BookService) { }

  ngOnInit(): void {
    
  }

  onAddNew(){
    const obj = {
      "id": this.id,
      "title" : this.title,
      "author" : this.author,
      "price" : this.price
    };
    this.service.addNewBook(obj).subscribe((data)=>{
      alert("Book Added successfully");
    })
  }
}
